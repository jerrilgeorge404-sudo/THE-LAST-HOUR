package com.projectecho.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Full-screen Android app shell for Project Echo.
 * The game itself remains Python. CI builds it with Pygbag and bundles the
 * generated browser runtime inside the APK; this WebView is embedded in the
 * app, so the player does not open an external browser or install Python.
 */
public final class MainActivity extends Activity {
    private WebView gameView;
    private TextView statusView;
    private LocalAssetServer assetServer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.rgb(5, 8, 11));
        getWindow().setNavigationBarColor(Color.rgb(5, 8, 11));
        enterImmersiveMode();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5, 8, 11));

        gameView = new WebView(this);
        gameView.setBackgroundColor(Color.rgb(5, 8, 11));
        gameView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        gameView.setVerticalScrollBarEnabled(false);
        gameView.setHorizontalScrollBarEnabled(false);
        gameView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (statusView != null) statusView.setVisibility(View.GONE);
                enterImmersiveMode();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                if (request != null && request.isForMainFrame() && statusView != null) {
                    statusView.setText("PROJECT ECHO COULD NOT START\n\nThe packaged game files did not load.\nPlease rebuild the Android package and try again.");
                    statusView.setVisibility(View.VISIBLE);
                }
            }
        });
        WebSettings settings = gameView.getSettings();
        settings.setJavaScriptEnabled(true); // Needed by the embedded Pygbag runtime.
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setDefaultTextEncodingName("UTF-8");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }
        gameView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage message) {
                // Keep runtime diagnostics available to Android logcat without showing browser UI.
                android.util.Log.d("ProjectEchoWeb", message.message() + " (" +
                        message.sourceId() + ":" + message.lineNumber() + ")");
                return true;
            }
        });

        statusView = new TextView(this);
        statusView.setText("THE LAST HOUR\nPROJECT ECHO\n\nINITIALIZING FACILITY...");
        statusView.setTextColor(Color.rgb(0, 215, 245));
        statusView.setTextSize(18);
        statusView.setGravity(Gravity.CENTER);
        statusView.setBackgroundColor(Color.rgb(5, 8, 11));
        statusView.setTypeface(android.graphics.Typeface.MONOSPACE);
        statusView.setPadding(24, 24, 24, 24);

        root.addView(gameView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(statusView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        try {
            assetServer = new LocalAssetServer();
            int port = assetServer.start();
            gameView.loadUrl("http://127.0.0.1:" + port + "/index.html");
        } catch (IOException e) {
            statusView.setText("PROJECT ECHO COULD NOT START\n\nThe local game server failed to start.\n" + e.getClass().getSimpleName());
        }
    }

    private void enterImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enterImmersiveMode();
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Leave the facility?")
                .setMessage("Exit THE LAST HOUR: PROJECT ECHO?")
                .setNegativeButton("CONTINUE PLAYING", (dialog, which) -> {
                    dialog.dismiss();
                    enterImmersiveMode();
                })
                .setPositiveButton("EXIT GAME", (dialog, which) -> finish())
                .show();
    }

    @Override
    protected void onDestroy() {
        if (gameView != null) {
            gameView.stopLoading();
            gameView.loadUrl("about:blank");
            gameView.destroy();
            gameView = null;
        }
        if (assetServer != null) assetServer.stop();
        super.onDestroy();
    }

    /** A private loopback-only HTTP server for serving bundled game files with correct MIME types. */
    private final class LocalAssetServer {
        private ServerSocket socket;
        private volatile boolean running;
        private final ExecutorService clients = Executors.newCachedThreadPool();

        int start() throws IOException {
            socket = new ServerSocket(0, 24, InetAddress.getByName("127.0.0.1"));
            running = true;
            Thread acceptThread = new Thread(() -> {
                while (running) {
                    try {
                        Socket client = socket.accept();
                        client.setSoTimeout(7000);
                        clients.execute(() -> serve(client));
                    } catch (IOException e) {
                        if (running) android.util.Log.w("ProjectEchoServer", "Accept failed", e);
                    }
                }
            }, "ProjectEchoAssetServer");
            acceptThread.setDaemon(true);
            acceptThread.start();
            return socket.getLocalPort();
        }

        void stop() {
            running = false;
            try { if (socket != null) socket.close(); } catch (IOException ignored) {}
            clients.shutdownNow();
        }

        private void serve(Socket client) {
            try (Socket s = client;
                 BufferedInputStream input = new BufferedInputStream(s.getInputStream());
                 BufferedOutputStream output = new BufferedOutputStream(s.getOutputStream())) {
                String requestLine = readLine(input);
                if (requestLine == null || requestLine.trim().isEmpty()) return;
                String[] parts = requestLine.split("\\s+");
                if (parts.length < 2) { writeError(output, 400, "Bad Request"); return; }
                String method = parts[0].toUpperCase(Locale.ROOT);
                if (!method.equals("GET") && !method.equals("HEAD")) {
                    writeError(output, 405, "Method Not Allowed");
                    return;
                }
                String rawPath = parts[1].split("\\?", 2)[0];
                String path;
                try {
                    path = URLDecoder.decode(rawPath, StandardCharsets.UTF_8.name());
                } catch (Exception e) {
                    writeError(output, 400, "Bad Request");
                    return;
                }
                String headerLine;
                while ((headerLine = readLine(input)) != null && !headerLine.isEmpty()) {
                    // Consume request headers until the blank separator line.
                }
                if (path.equals("/") || path.isEmpty()) path = "/index.html";
                if (path.contains("..") || path.indexOf('\\') >= 0 || path.startsWith("//")) {
                    writeError(output, 403, "Forbidden");
                    return;
                }
                while (path.startsWith("/")) path = path.substring(1);
                String assetPath = "game/" + path;
                try (InputStream body = getAssets().open(assetPath, android.content.res.AssetManager.ACCESS_STREAMING)) {
                    String mime = mimeType(path);
                    String header = "HTTP/1.1 200 OK\r\n" +
                            "Content-Type: " + mime + "\r\n" +
                            "Transfer-Encoding: chunked\r\n" +
                            "Connection: close\r\n" +
                            "Cache-Control: no-cache\r\n" +
                            "X-Content-Type-Options: nosniff\r\n\r\n";
                    output.write(header.getBytes(StandardCharsets.US_ASCII));
                    if (method.equals("GET")) writeChunked(body, output);
                    output.flush();
                } catch (IOException notFound) {
                    writeError(output, 404, "Not Found");
                }
            } catch (IOException ignored) {
                // A view refresh or app shutdown commonly closes a client early.
            }
        }

        private String readLine(InputStream in) throws IOException {
            ByteArrayOutputStream line = new ByteArrayOutputStream();
            while (true) {
                int b = in.read();
                if (b == -1) return line.size() == 0 ? null : line.toString("UTF-8");
                if (b == '\n') {
                    byte[] raw = line.toByteArray();
                    int length = raw.length;
                    if (length > 0 && raw[length - 1] == '\r') length--;
                    String text = new String(raw, 0, length, StandardCharsets.UTF_8);
                    return text;
                }
                line.write(b);
                if (line.size() > 16384) throw new IOException("HTTP header too long");
            }
        }

        private void writeChunked(InputStream in, OutputStream out) throws IOException {
            byte[] buffer = new byte[16 * 1024];
            int count;
            while ((count = in.read(buffer)) != -1) {
                if (count == 0) continue;
                out.write(Integer.toHexString(count).getBytes(StandardCharsets.US_ASCII));
                out.write("\r\n".getBytes(StandardCharsets.US_ASCII));
                out.write(buffer, 0, count);
                out.write("\r\n".getBytes(StandardCharsets.US_ASCII));
            }
            out.write("0\r\n\r\n".getBytes(StandardCharsets.US_ASCII));
        }

        private void writeError(OutputStream out, int code, String reason) throws IOException {
            byte[] data = (reason + "\n").getBytes(StandardCharsets.UTF_8);
            String head = "HTTP/1.1 " + code + " " + reason + "\r\n" +
                    "Content-Type: text/plain; charset=utf-8\r\n" +
                    "Content-Length: " + data.length + "\r\n" +
                    "Connection: close\r\n\r\n";
            out.write(head.getBytes(StandardCharsets.US_ASCII));
            out.write(data);
            out.flush();
        }

        private String mimeType(String path) {
            String p = path.toLowerCase(Locale.ROOT);
            if (p.endsWith(".html")) return "text/html; charset=utf-8";
            if (p.endsWith(".js") || p.endsWith(".mjs")) return "text/javascript; charset=utf-8";
            if (p.endsWith(".css")) return "text/css; charset=utf-8";
            if (p.endsWith(".json")) return "application/json; charset=utf-8";
            if (p.endsWith(".wasm")) return "application/wasm";
            if (p.endsWith(".png")) return "image/png";
            if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
            if (p.endsWith(".webp")) return "image/webp";
            if (p.endsWith(".svg")) return "image/svg+xml";
            if (p.endsWith(".woff2")) return "font/woff2";
            if (p.endsWith(".woff")) return "font/woff";
            if (p.endsWith(".ttf")) return "font/ttf";
            if (p.endsWith(".xml")) return "application/xml; charset=utf-8";
            if (p.endsWith(".zip")) return "application/zip";
            if (p.endsWith(".data") || p.endsWith(".bin")) return "application/octet-stream";
            return "application/octet-stream";
        }
    }
}
