# THE LAST HOUR: PROJECT ECHO — Android APK Builder

This package is intended to produce an installable Android app from the existing Python + Raylib/Pyray game and its mobile touch controls.

## What the player gets

- An Android app which opens directly in full-screen landscape mode; it does not launch Chrome or another external browser.
- The game's Python source and the generated runtime assets bundled in the APK.
- On-screen mobile controls are supplied by the existing modified game source: virtual joystick, touch-drag look, USE, TAKE, LIGHT, BAG, JUMP, DROP and PAUSE.
- No separate Python, Raylib, Pillow, or other game module installation by the player.
- Bundled files are served by a loopback-only local server within the app, so after installation the game assets are available offline.

## Important technical detail

The game source remains Python; it has not been rewritten as a JavaScript game. The build pipeline uses Pygbag to create a browser-compatible WebAssembly runtime from the Python/Raylib project, then packages that runtime inside a full-screen Android APK. The WebView is embedded in the app, not launched as a separate browser. This is the practical packaging path for the existing Python/Raylib code without porting all of its rendering and game logic to a separate native Android engine.

**This ZIP is a build project, not an APK.** The Android SDK and Gradle are not installed in the workspace where this was prepared, and the required packages could not be downloaded here, so a real APK could not be compiled or phone-tested in this session. The workflow below builds it on a hosted runner and attaches the APK to a GitHub Release only if every build step succeeds.

## Create the APK and its download link

1. Download and unzip this project.
2. Create a new GitHub repository. For a direct download that any player can access without signing in, make the repository **public**. A private repository will make its releases private too.
3. Upload the contents of this folder to the repository root (the `.github` folder must be included). Ensure the default branch is named `main` or run the workflow manually from the Actions tab.
4. Open **Actions → Build Project Echo Android APK**. The workflow builds the Python game runtime, embeds it in the Android app, compiles a debug-signed APK, and creates a release if successful.
5. When the workflow is green, open **Releases** and download `project-echo.apk`. For a public repository the file's direct URL is:
   `https://github.com/OWNER/REPOSITORY/releases/latest/download/project-echo.apk`

Every successful workflow run also uploads an artifact named `project-echo-android-apk` (kept for 30 days).

## First-run test checklist

- Install the APK on an Android 8.0+ device (API 26+ is recommended; manifest minimum is API 24).
- Open the app and verify the PROJECT ECHO title/menu appears.
- Check the virtual joystick, right-side camera drag and the USE/TAKE/LIGHT/BAG/JUMP/DROP/PAUSE controls.
- Test one complete room transition, one puzzle interaction, audio, and the ending sequence.
- If the startup screen remains on “INITIALIZING FACILITY” or the app shows a load error, open the GitHub Actions log and check the Pygbag build output/runtime errors. The APK must not be distributed as playable until those checks pass on a real device.

## Build configuration

- Android application ID: `com.projectecho.game`
- Display name: `THE LAST HOUR: PROJECT ECHO`
- Orientation: landscape
- Android `minSdk`: 24
- Android compile SDK: 35
- Gradle: 8.11.1, Android Gradle Plugin: 8.9.2, Java: 17

The release artifact is debug-signed for convenient testing and sideloading; it is not configured as a Play Store production release.
